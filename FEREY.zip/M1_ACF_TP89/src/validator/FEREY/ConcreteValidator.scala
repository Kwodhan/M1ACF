package validator.FEREY;
import bank._


// Automatic conversion of bank.message to tp89.messages and Nat to bank.Nat
object Converter{
  implicit def bank2message(m:bank.message):tp89.message=
    m match {
    case bank.Pay((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p)) => tp89.Pay((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))
    case bank.Ack((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p)) => tp89.Ack((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))
    case bank.Cancel((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i)))) => tp89.Cancel((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))))
  }
  
  implicit def trans2bankTrans(l:List[((Nat.nat,(Nat.nat,Nat.nat)),Nat.nat)]): List[((bank.Nat.nat,(bank.Nat.nat,bank.Nat.nat)),bank.Nat.nat)]=
    l match {
    case Nil => Nil
    case ((Nat.Nata(c),(Nat.Nata(m),Nat.Nata(i))),Nat.Nata(p))::r => ((bank.Nat.Nata(c),(bank.Nat.Nata(m),bank.Nat.Nata(i))),bank.Nat.Nata(p))::trans2bankTrans(r)
  }
}

import Converter._

object HOL {

trait equal[A] {
  val `HOL.equal`: (A, A) => Boolean
}
def equal[A](a: A, b: A)(implicit A: equal[A]): Boolean = A.`HOL.equal`(a, b)

def eq[A : equal](a: A, b: A): Boolean = equal[A](a, b)

} /* object HOL */

object Code_Numeral {

def integer_of_nat(x0: Nat.nat): BigInt = x0 match {
  case Nat.Nata(x) => x
}

} /* object Code_Numeral */

object Nat {

abstract sealed class nat
final case class Nata(a: BigInt) extends nat

def equal_nata(m: nat, n: nat): Boolean =
  Code_Numeral.integer_of_nat(m) == Code_Numeral.integer_of_nat(n)

implicit def equal_nat: HOL.equal[nat] = new HOL.equal[nat] {
  val `HOL.equal` = (a: nat, b: nat) => equal_nata(a, b)
}

def less_nat(m: nat, n: nat): Boolean =
  Code_Numeral.integer_of_nat(m) < Code_Numeral.integer_of_nat(n)

def zero_nat: nat = Nata(BigInt(0))

def less_eq_nat(m: nat, n: nat): Boolean =
  Code_Numeral.integer_of_nat(m) <= Code_Numeral.integer_of_nat(n)

} /* object Nat */

object Product_Type {

def equal_proda[A : HOL.equal, B : HOL.equal](x0: (A, B), x1: (A, B)): Boolean =
  (x0, x1) match {
  case ((x1, x2), (y1, y2)) => HOL.eq[A](x1, y1) && HOL.eq[B](x2, y2)
}

implicit def equal_prod[A : HOL.equal, B : HOL.equal]: HOL.equal[(A, B)] = new
  HOL.equal[(A, B)] {
  val `HOL.equal` = (a: (A, B), b: (A, B)) => equal_proda[A, B](a, b)
}

} /* object Product_Type */

object tp89 {

import /*implicits*/ Product_Type.equal_prod, Nat.equal_nat

abstract sealed class message
final case class Pay(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Ack(a: (Nat.nat, (Nat.nat, Nat.nat)), b: Nat.nat) extends
  message
final case class Cancel(a: (Nat.nat, (Nat.nat, Nat.nat))) extends message

abstract sealed class SomeTrans
final case class Nonea() extends SomeTrans
final case class Integer(a: Nat.nat) extends SomeTrans

abstract sealed class etatTrans
final case class Encours() extends etatTrans
final case class Ok() extends etatTrans
final case class Abort() extends etatTrans

def equal_etatTrans(x0: etatTrans, x1: etatTrans): Boolean = (x0, x1) match {
  case (Ok(), Abort()) => false
  case (Abort(), Ok()) => false
  case (Encours(), Abort()) => false
  case (Abort(), Encours()) => false
  case (Encours(), Ok()) => false
  case (Ok(), Encours()) => false
  case (Abort(), Abort()) => true
  case (Ok(), Ok()) => true
  case (Encours(), Encours()) => true
}

def export(x0: List[((Nat.nat, (Nat.nat, Nat.nat)),
                      (SomeTrans, (SomeTrans, etatTrans)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat)]
  =
  x0 match {
  case Nil => Nil
  case (x2, (m2, (Integer(c2), e2))) :: xs =>
    (if (equal_etatTrans(e2, Ok())) (x2, c2) :: export(xs) else export(xs))
  case (x2, (m2, (Nonea(), e2))) :: xs => export(xs)
}

def updateLigneAck(uu: Nat.nat,
                    x1: ((Nat.nat, (Nat.nat, Nat.nat)),
                          (SomeTrans, (SomeTrans, etatTrans)))):
      ((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))
  =
  (uu, x1) match {
  case (uu, (x2, (m2, (c2, Abort())))) => (x2, (m2, (c2, Abort())))
  case (m1, (x2, (Integer(m2), (Nonea(), Encours())))) =>
    (if (Nat.less_eq_nat(m1, m2)) (x2, (Integer(m1), (Nonea(), Encours())))
      else (x2, (Integer(m2), (Nonea(), Encours()))))
  case (m1, (x2, (Integer(m2), (Integer(v2), Encours())))) =>
    (if (Nat.less_eq_nat(m1, m2))
      (if (Nat.less_eq_nat(m1, v2)) (x2, (Integer(m1), (Integer(v2), Ok())))
        else (x2, (Integer(m1), (Integer(v2), Encours()))))
      else (x2, (Integer(m2), (Integer(v2), Encours()))))
  case (uv, (x2, (m2, (c2, Ok())))) => (x2, (m2, (c2, Ok())))
  case (m1, (v, (Nonea(), (Nonea(), Encours())))) =>
    (v, (Integer(m1), (Nonea(), Encours())))
  case (m1, (v, (Nonea(), (Integer(v2), Encours())))) =>
    (if (Nat.less_eq_nat(m1, v2)) (v, (Integer(m1), (Integer(v2), Ok())))
      else (v, (Integer(m1), (Integer(v2), Encours()))))
}

def updateAck(x0: ((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat),
               x1: List[((Nat.nat, (Nat.nat, Nat.nat)),
                          (SomeTrans, (SomeTrans, etatTrans)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))]
  =
  (x0, x1) match {
  case ((x1, c1), Nil) => List((x1, (Integer(c1), (Nonea(), Encours()))))
  case ((x1, c1), (x2, (m2, (c2, e2))) :: xs) =>
    (if (Product_Type.equal_proda[Nat.nat, (Nat.nat, Nat.nat)](x2, x1))
      updateLigneAck(c1, (x2, (m2, (c2, e2)))) :: xs
      else (x2, (m2, (c2, e2))) :: updateAck((x1, c1), xs))
}

def updateLignePay(uu: Nat.nat,
                    x1: ((Nat.nat, (Nat.nat, Nat.nat)),
                          (SomeTrans, (SomeTrans, etatTrans)))):
      ((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))
  =
  (uu, x1) match {
  case (uu, (x2, (m2, (c2, Abort())))) => (x2, (m2, (c2, Abort())))
  case (v1, (x2, (Integer(m2), (Nonea(), Encours())))) =>
    (if (Nat.less_eq_nat(m2, v1)) (x2, (Integer(m2), (Integer(v1), Ok())))
      else (x2, (Integer(m2), (Integer(v1), Encours()))))
  case (v1, (x2, (Integer(m2), (Integer(v2), Encours())))) =>
    (if (Nat.less_nat(v2, v1))
      (if (Nat.less_eq_nat(m2, v1)) (x2, (Integer(m2), (Integer(v1), Ok())))
        else (x2, (Integer(m2), (Integer(v1), Encours()))))
      else (x2, (Integer(m2), (Integer(v2), Encours()))))
  case (uv, (x2, (m2, (c2, Ok())))) => (x2, (m2, (c2, Ok())))
  case (v1, (v, (Nonea(), (Nonea(), Encours())))) =>
    (v, (Nonea(), (Integer(v1), Encours())))
  case (v1, (v, (Nonea(), (Integer(v2), Encours())))) =>
    (if (Nat.less_nat(v2, v1)) (v, (Nonea(), (Integer(v1), Encours())))
      else (v, (Nonea(), (Integer(v2), Encours()))))
}

def updatePay(x0: ((Nat.nat, (Nat.nat, Nat.nat)), Nat.nat),
               x1: List[((Nat.nat, (Nat.nat, Nat.nat)),
                          (SomeTrans, (SomeTrans, etatTrans)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))]
  =
  (x0, x1) match {
  case ((x1, c1), Nil) => List((x1, (Nonea(), (Integer(c1), Encours()))))
  case ((x1, c1), (x2, (m2, (c2, e2))) :: xs) =>
    (if (Product_Type.equal_proda[Nat.nat, (Nat.nat, Nat.nat)](x2, x1))
      updateLignePay(c1, (x2, (m2, (c2, e2)))) :: xs
      else (x2, (m2, (c2, e2))) :: updatePay((x1, c1), xs))
}

def updateLigneCancel(x0: ((Nat.nat, (Nat.nat, Nat.nat)),
                            (SomeTrans, (SomeTrans, etatTrans)))):
      ((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))
  =
  x0 match {
  case (x2, (m2, (c2, e2))) => (x2, (m2, (c2, Abort())))
}

def updateCancel(x1: (Nat.nat, (Nat.nat, Nat.nat)),
                  x1a: List[((Nat.nat, (Nat.nat, Nat.nat)),
                              (SomeTrans, (SomeTrans, etatTrans)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))]
  =
  (x1, x1a) match {
  case (x1, Nil) => List((x1, (Nonea(), (Nonea(), Abort()))))
  case (x1, (x2, (m2, (c2, e2))) :: xs) =>
    (if (Product_Type.equal_proda[Nat.nat, (Nat.nat, Nat.nat)](x2, x1))
      updateLigneCancel((x2, (m2, (c2, e2)))) :: xs
      else (x2, (m2, (c2, e2))) :: updateCancel(x1, xs))
}

def traiterMessage(x0: message,
                    tb: List[((Nat.nat, (Nat.nat, Nat.nat)),
                               (SomeTrans, (SomeTrans, etatTrans)))]):
      List[((Nat.nat, (Nat.nat, Nat.nat)), (SomeTrans, (SomeTrans, etatTrans)))]
  =
  (x0, tb) match {
  case (Pay(transid, am), tb) =>
    (if (Nat.less_nat(Nat.zero_nat, am)) updatePay((transid, am), tb) else tb)
  case (Ack(transid, am), tb) =>
    (if (Nat.less_eq_nat(Nat.zero_nat, am)) updateAck((transid, am), tb)
      else tb)
  case (Cancel(transid), tb) => updateCancel(transid, tb)
}

} /* object tp89 */


/* The object to complete */ 
class ConcreteValidator extends TransValidator{
  
  var t: List[((Nat.nat, (Nat.nat, Nat.nat)),
                               (tp89.SomeTrans, (tp89.SomeTrans, tp89.etatTrans)))] = List()
  

	// TODO
	def process(m:message){
	  t = tp89.traiterMessage(m, t);
	}

	// TODO
	def getValidTrans: List[((bank.Nat.nat, (bank.Nat.nat,bank.Nat.nat)),bank.Nat.nat)]= {
	  tp89.export(t);
	}

	// TODO
	def authors= "FEREY"
	
	
	
}
